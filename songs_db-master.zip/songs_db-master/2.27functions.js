
Command line
-mongod     starts server
Mongo Shell Commands
 - use db
 - show collections
